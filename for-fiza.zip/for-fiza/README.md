# For Fiza ❤️ — Setup Notes

This is a complete, working premium mobile web app. Everything already runs —
buttons, page transitions, the envelope, the audio player, and the surprise
finale all work right now.

## Replace the placeholders with the real content

I couldn't access your actual photos or voice recording, so three
placeholder files were generated so nothing looks broken:

- `images/photo1.jpg` — used on the Home page background and the Surprise
  page background (currently a soft dark pink gradient).
- `images/photo2.jpg` — used on the Love page background (currently a soft
  dark gradient).
- `audio/voice.mp3` — used on the Voice page and auto-played on the Surprise
  page (currently 3 seconds of silence).

**To finish it:** just drop your real files into `images/` and `audio/`
using those exact same file names, overwriting the placeholders. No code
changes are needed — the app already points at those paths.

## Notes on the voice message

Browsers block audio autoplay until the user has interacted with the page
at least once. Because your visitor will have already tapped buttons to
reach the Surprise page, the voice message will autoplay correctly at that
point. If a browser ever blocks it anyway, they can just tap the play
button on the Voice page.

## Running it

Because the pages load audio/images from local paths, open this project
through a local server rather than double-clicking `index.html` (some
browsers restrict local file access otherwise). The simplest way:

```
cd for-fiza
python3 -m http.server 8080
```

Then open `http://localhost:8080` on your phone or browser.

## Editing the words

- Home page text: `index.html` → `#page-home`
- Love page messages (cycle with Next/Previous): `script.js` →
  `loveMessages` array
- Letter text: `script.js` → `letterFullText`
- Surprise ending line: `script.js` → `surpriseFullMessage`
